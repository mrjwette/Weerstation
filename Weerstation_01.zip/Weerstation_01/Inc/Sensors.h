/*
 * Sensors.h
 *
 *  Created on: 5 okt. 2018
 *      Author: Dominic
 */

#ifndef SENSORS_H_
#define SENSORS_H_

float measureHumidity();
float measureTemperature();
float measurePressure();

#endif /* SENSORS_H_ */
